<img src="<?php echo e(asset('storage/diplomes/logo.jpg')); ?>" class="w-8 h-8" />
<?php /**PATH C:\wamp64\www\ashempire2\resources\views/components/app-logo-icon.blade.php ENDPATH**/ ?>