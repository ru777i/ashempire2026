<div>
    <!-- Well begun is half done. - Aristotle -->
</div><?php /**PATH C:\wamp64\www\ashempire2\resources\views/components/form/luther.blade.php ENDPATH**/ ?>