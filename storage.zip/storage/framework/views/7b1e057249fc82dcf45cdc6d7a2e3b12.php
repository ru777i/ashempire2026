

<tbody <?php echo e($attributes); ?> data-flux-rows>
    <?php echo e($slot); ?>

</tbody>
<?php /**PATH C:\wamp64\www\ashempire2\vendor\livewire\flux\src/../stubs/resources/views/flux/table/rows.blade.php ENDPATH**/ ?>