<div class="mt-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-lg">
    <div class="border-b border-slate-200 bg-slate-50 px-4 py-3">
        <div class="flex items-center justify-between">
            <div>
                <h3 class="text-lg font-semibold text-slate-800">Programme de l'emploi du temps</h3>
                <p class="text-sm text-slate-500">Consultation des séances par jour</p>
            </div>
            <div class="rounded-full bg-blue-100 px-3 py-1 text-xs font-medium text-blue-700">
                <?php echo e($this->seances->count()); ?> séance(s)
            </div>
        </div>
    </div>

    <div class="grid gap-4 p-4 xl:grid-cols-5">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $daySeances = $this->seances->filter(fn($item) => $item->jour === $day)->sortBy('heureDebut');
            ?>

            <div class="rounded-xl border border-slate-200 bg-slate-50 p-3">
                <div class="mb-3 border-b border-slate-200 pb-2">
                    <h4 class="font-semibold text-slate-800"><?php echo e($day); ?></h4>
                    <p class="text-xs text-slate-500"><?php echo e($daySeances->count()); ?> séance(s)</p>
                </div>

                <div class="space-y-2">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $daySeances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if (isset($component)) { $__componentOriginal1db8c57e729d67f7d4103875cf3230cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1db8c57e729d67f7d4103875cf3230cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::modal.trigger','data' => ['name' => ''.e(Auth::user()->role=='secretaire' ? 'Seance': '').'','class' => 'm-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::modal.trigger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e(Auth::user()->role=='secretaire' ? 'Seance': '').'','class' => 'm-4']); ?>
                            <button type="button" wire:click="<?php echo e(Auth::user()->role=='secretaire' ? 'editSeance( '.$seance->id.' )':''); ?>"
                                class="w-full rounded-lg border border-blue-200 bg-white p-3 text-left text-xs text-slate-700 shadow-sm transition hover:border-blue-400 hover:shadow-md">
                                <div class="flex items-center justify-between">
                                    <span
                                        class="font-semibold text-slate-800"><?php echo e($seance->module->nom ?? 'Module'); ?></span>
                                    <span
                                        class="rounded-full bg-blue-100 px-2 py-0.5 text-[10px] font-semibold text-blue-700">
                                        <?php echo e($seance->type); ?>

                                    </span>
                                </div>
                                <div class="mt-1 text-slate-600"><?php echo e($seance->heureDebut); ?> - <?php echo e($seance->heureFin); ?>

                                </div>
                                <div class="text-slate-600">Salle: <?php echo e($seance->salle->nom ?? '—'); ?></div>
                                <div class="text-slate-600">Session: <?php echo e($seance->sess->code); ?></div>
                                <div class="text-slate-600">Formation: <?php echo e($seance->sess->formation->nom ?? '—'); ?>

                                </div>
                                <div class="text-slate-600">Formateur: <?php echo e($seance->formateur->user->name ?? '—'); ?>

                                </div>
                            </button>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1db8c57e729d67f7d4103875cf3230cb)): ?>
<?php $attributes = $__attributesOriginal1db8c57e729d67f7d4103875cf3230cb; ?>
<?php unset($__attributesOriginal1db8c57e729d67f7d4103875cf3230cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1db8c57e729d67f7d4103875cf3230cb)): ?>
<?php $component = $__componentOriginal1db8c57e729d67f7d4103875cf3230cb; ?>
<?php unset($__componentOriginal1db8c57e729d67f7d4103875cf3230cb); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div
                            class="rounded-lg border border-dashed border-slate-300 bg-slate-100 px-3 py-4 text-center text-sm text-slate-500">
                            Aucune séance
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>
<?php /**PATH C:\wamp64\www\ashempire2\resources\views/livewire/emploi-temp/programme-emploi-temps.blade.php ENDPATH**/ ?>