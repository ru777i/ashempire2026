<div class="p-6">

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session()->has('message')): ?>
        <div class="mb-4 rounded-lg bg-green-100 px-4 py-3 text-green-700">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session()->has('error')): ?>
        <div class="mb-4 rounded-lg bg-red-100 px-4 py-3 text-red-700">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>



    
    <div class="mb-6 flex items-center justify-between">

        <div>
            <h1 class="text-2xl font-bold text-gray-800">
                Mes recours
            </h1>

            <p class="text-sm text-gray-500">
                Consultez et gérez vos demandes de recours.
            </p>
        </div>


        <button
            wire:click="create"
            class="rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700">

            + Nouveau recours

        </button>

    </div>





    
    <div class="overflow-hidden rounded-xl border bg-white shadow">


        <table class="w-full text-left">


            <thead class="bg-gray-100 text-sm text-gray-600">

                <tr>

                    <th class="px-5 py-3">
                        Objet
                    </th>


                    <th class="px-5 py-3">
                        Type
                    </th>


                    <th class="px-5 py-3">
                        Formateur
                    </th>


                    <th class="px-5 py-3">
                        Statut
                    </th>


                    <th class="px-5 py-3">
                        Réponse
                    </th>


                    <th class="px-5 py-3">
                        Actions
                    </th>

                </tr>

            </thead>



            <tbody class="divide-y">


            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $recours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>


                <tr>


                    
                    <td class="px-5 py-4">

                        <div class="font-semibold text-gray-800">
                            <?php echo e($recour->objet); ?>

                        </div>


                        <div class="text-sm text-gray-500">

                            <?php echo e(Str::limit($recour->description,50)); ?>


                        </div>

                    </td>




                    
                    <td class="px-5 py-4">

                        <span class="rounded-full bg-gray-100 px-3 py-1 text-sm">

                            <?php echo e(ucfirst($recour->type)); ?>


                        </span>

                    </td>





                    
                    <td class="px-5 py-4">


                        <?php echo e($recour->formateur?->user?->name ?? 'Non défini'); ?>



                    </td>





                    
                    <td class="px-5 py-4">


                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php switch($recour->statut):


                            case ('en_attente'): ?>

                                <span class="rounded-full bg-yellow-100 px-3 py-1 text-sm text-yellow-700">

                                    En attente

                                </span>

                            <?php break; ?>



                            <?php case ('en_cours'): ?>

                                <span class="rounded-full bg-blue-100 px-3 py-1 text-sm text-blue-700">

                                    En cours

                                </span>

                            <?php break; ?>



                            <?php case ('accepte'): ?>

                                <span class="rounded-full bg-green-100 px-3 py-1 text-sm text-green-700">

                                    Accepté

                                </span>

                            <?php break; ?>



                            <?php case ('rejete'): ?>

                                <span class="rounded-full bg-red-100 px-3 py-1 text-sm text-red-700">

                                    Rejeté

                                </span>

                            <?php break; ?>



                            <?php default: ?>

                                <span class="rounded-full bg-gray-100 px-3 py-1 text-sm">

                                    <?php echo e($recour->statut); ?>


                                </span>


                        <?php endswitch; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


                    </td>






                    
                    <td class="max-w-xs px-5 py-4">


                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($recour->reponse): ?>


                            <p class="text-sm text-gray-700">

                                <?php echo e(Str::limit($recour->reponse,60)); ?>


                            </p>


                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($recour->date_traitement): ?>

                                <span class="text-xs text-gray-400">

                                    Traité le :
                                    <?php echo e($recour->date_traitement->format('d/m/Y')); ?>


                                </span>

                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


                        <?php else: ?>


                            <span class="text-sm text-gray-400">

                                Pas encore traité

                            </span>


                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


                    </td>







                    
                    <td class="px-5 py-4">


                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($recour->statut === 'en_attente'): ?>


                            <div class="flex gap-3">


                                <button
                                    wire:click="edit(<?php echo e($recour->id); ?>)"
                                    class="text-blue-600 hover:underline">

                                    Modifier

                                </button>



                                <button
                                    wire:click="delete(<?php echo e($recour->id); ?>)"
                                    onclick="return confirm('Supprimer ce recours ?')"
                                    class="text-red-600 hover:underline">

                                    Supprimer

                                </button>


                            </div>


                        <?php else: ?>


                            <span class="text-sm text-gray-400">

                                Verrouillé

                            </span>


                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


                    </td>


                </tr>



            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>


                <tr>

                    <td colspan="6" class="px-5 py-8 text-center text-gray-500">

                        Aucun recours enregistré.

                    </td>

                </tr>


            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>



            </tbody>


        </table>


    </div>



    
    <div class="mt-5">

        <?php echo e($recours->links()); ?>


    </div>







    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showModal): ?>


        <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/50">


            <div class="w-full max-w-xl rounded-xl bg-white p-6 shadow-xl">


                <h2 class="mb-5 text-xl font-bold">


                    <?php echo e($editMode ? 'Modifier le recours' : 'Nouveau recours'); ?>



                </h2>




                
                <label class="mb-2 block text-sm font-medium">

                    Destinataire

                </label>


                <select
                    wire:model="formateur_id"
                    class="mb-4 w-full rounded-lg border-gray-300">


                    <option value="">

                        Choisir un formateur

                    </option>


                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $formateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <option value="<?php echo e($formateur->id); ?>">

                            <?php echo e($formateur->user->name); ?>


                        </option>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


                </select>


                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['formateur_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-sm text-red-600">

                        <?php echo e($message); ?>


                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>







                
                <input
                    wire:model="objet"
                    type="text"
                    placeholder="Objet du recours"
                    class="mb-4 w-full rounded-lg border-gray-300">


                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['objet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-sm text-red-600">

                        <?php echo e($message); ?>


                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>





                
                <select
                    wire:model="type"
                    class="mb-4 w-full rounded-lg border-gray-300">


                    <option value="">
                        Choisir un type
                    </option>


                    <option value="note">
                        Erreur de note
                    </option>


                    <option value="absence">
                        Absence
                    </option>


                    <option value="autre">
                        Autre
                    </option>


                </select>





                
                <textarea
                    wire:model="description"
                    rows="5"
                    placeholder="Expliquez votre problème..."
                    class="mb-5 w-full rounded-lg border-gray-300"></textarea>





                <div class="flex justify-end gap-3">


                    <button
                        wire:click="$set('showModal',false)"
                        class="rounded-lg border px-4 py-2">

                        Annuler

                    </button>




                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($editMode): ?>


                        <button
                            wire:click="update"
                            class="rounded-lg bg-green-600 px-4 py-2 text-white">

                            Modifier

                        </button>


                    <?php else: ?>


                        <button
                            wire:click="save"
                            class="rounded-lg bg-blue-600 px-4 py-2 text-white">

                            Envoyer

                        </button>


                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


                </div>


            </div>


        </div>


    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


</div>
<?php /**PATH C:\wamp64\www\ashempire2\resources\views/livewire/apprenant/recour.blade.php ENDPATH**/ ?>