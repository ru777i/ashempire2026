<svg class="w-" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15"/>
</svg><?php /**PATH C:\wamp64\www\ashempire2\storage\framework\views/aa2e33f67dea57b25ac29b6c478a346f.blade.php ENDPATH**/ ?>