<?php

use Livewire\Component;

return new class extends Component {
    protected function view($data = [])
    {
        return app('view')->file('C:\wamp64\www\ashempire2\storage\framework\views/livewire/views/e92bf765.blade.php', $data);
    }
}; 