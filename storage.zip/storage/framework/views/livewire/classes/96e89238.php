<?php

use Livewire\Component;
use Livewire\Attributes\Title;

return new #[Title('Appearance settings')] class extends Component {
    //

    protected function view($data = [])
    {
        return app('view')->file('C:\wamp64\www\ashempire2\storage\framework\views/livewire/views/96e89238.blade.php', $data);
    }
}; 