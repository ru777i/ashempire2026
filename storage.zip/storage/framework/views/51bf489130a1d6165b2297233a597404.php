

<div <?php echo e($attributes->class('flex items-center justify-between gap-2 min-h-10')); ?> data-flux-sidebar-header>
    <?php echo e($slot); ?>

</div><?php /**PATH C:\wamp64\www\ashempire2\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/header.blade.php ENDPATH**/ ?>