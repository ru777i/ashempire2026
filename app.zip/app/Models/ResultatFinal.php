<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ResultatFinal extends Model
{
       public function inscription()
    {
        return $this->belongsTo(Inscription::class);
    }
}
