<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Apprenant extends Model
{
    protected $fillable = [
        'prenom',
        'matricule',
        'sexe',
        'dateNaissance',
        'user_id'

    ];
    public function dipomes(){
    return $this->hasMany(Diplome::class);
    }
     public function user() {
        return $this->belongsTo(User::class);
    }

    public function inscriptions() {
        return $this->hasMany(Inscription::class);
    }
    //
}
