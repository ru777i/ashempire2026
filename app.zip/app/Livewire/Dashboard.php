<?php

namespace App\Livewire;

use App\Models\Formation;
use App\Models\Inscription;
use App\Models\Sessionn;
use Carbon\Carbon;
use Livewire\Component;

class Dashboard extends Component
{
    public $formationsEncous;
    public $sesionEncours;
    public $inscriptionsEncours;
    public $derniersInsription;

    public $labels = [];
    public $data = [];

    public function mount()
    {
        $this->chargerStatistiques();
    }
    public function getNombreSessionEnCours()
    {
        return Sessionn::where('statut', 'En cours')->count();
    }
    public function getNombreApprenantsFormation()
    {
        return Inscription::whereHas('sessionn', function ($query) {
            $query->whereDate('dateDebut', '<=', Carbon::today())
                ->whereDate('dateFin', '>=', Carbon::today());
        })->count();
    }
    // public function getNombreSessionEnCours()
    // {
    //     return Sessionn::whereDate('dateDebut', '<=', Carbon::today())
    //         ->whereDate('dateFin', '>=', Carbon::today())
    //         ->count();
    // }

    public function chargerStatistiques()
    {
        $formations = Formation::withCount('inscriptions')->get();

        $this->labels = $formations->pluck('nom')->toArray();
        $this->data = $formations->pluck('inscriptions_count')->toArray();
    }
    public function donneesChartFormation()
    {
        $formations = Formation::withCount('inscriptions')
            ->select('id', 'nom')
            ->get();

        return [
            'labels' => $formations->pluck('nom')->toArray(),
            'data'   => $formations->pluck('inscriptions_count')->toArray(),
        ];
    }
    public function render()
    {
        $this->sesionEncours = Sessionn::where('statut', 'en cours')->get();
        $this->inscriptionsEncours = Inscription::where('statut', 'En formation')->get();
        $inscriptions = Inscription::orderBy('created_at', 'desc')->paginate(4);
        $nbA=$this->getNombreApprenantsFormation();
        $nbS=$this->getNombreSessionEnCours();
        return view('dashboard', compact('inscriptions','nbA','nbS'));
    }
}
