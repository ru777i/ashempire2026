<?php

namespace App\Livewire\Annoces;

use Livewire\Component;

class CreateAnnonce extends Component
{
    public function render()
    {
        return view('livewire.annoces.create-annonce');
    }
}
