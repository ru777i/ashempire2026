<div class="flex h-full w-full flex-1 flex-col gap-4 rounded-xl">
    <div class="grid auto-rows-min gap-4 md:grid-cols-3">
        <div
            class="relative flex items-center justify-center aspect-video overflow-hidden rounded-xl border border-neutral-200 dark:border-neutral-700">
            <div class="relative w-full h-full flex items-center justify-center">
                <canvas id="formationChart"></canvas>
            </div>

            @script
                <script>
                    const ctx = document.getElementById('formationChart');

                    new Chart(ctx, {
                        type: 'pie',

                        data: {
                            labels: @json($labels),

                            datasets: [{
                                label: 'Nombre d\'inscriptions',
                                data: @json($data),
                                borderWidth: 1
                            }]
                        },

                        options: {
                            responsive: true,

                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }

                    });
                </script>
            @endscript
        </div>
        <div class="relative aspect-video overflow-hidden rounded-xl border border-neutral-200 dark:border-neutral-700">
            <div class="relative aspect-video rounded-xl border p-6">
                <div class="flex flex-col justify-center h-full">
		   
                    <span class="text-gray-500 text-sm flex items-center  justify-center">
                       <flux:icon.user-group variant="solid" class=" size-10 text-green-500 dark:text-amber-300"   /> <span> Apprenants en formation  </span>
                    </span>

                    <span class="text-5xl font-bold text-green-600 flex justify-center">
                        {{ $nbA }}
                    </span>
                </div>
            </div>
        </div>
        <div class="relative aspect-video overflow-hidden rounded-xl border border-neutral-200 dark:border-neutral-700">
            <div class="relative aspect-video rounded-xl border p-6">
                <div class="flex flex-col justify-center h-full">
                     <span class="text-gray-500 text-sm flex items-center justify-center">
                       <flux:icon.calendar variant="solid" class=" size-10 text-blue-500 dark:text-amber-300"   /> Session en cours
                    </span>

                    <span class="text-5xl font-bold text-blue-600 flex justify-center items-center">
                        {{ $nbS }}
                    </span>
                </div>
            </div>
        </div>
    </div>
    <div class="relative h-full flex-1 overflow-hidden rounded-xl border border-neutral-200 dark:border-neutral-700">
        <flux:heading size="xl" class="p-3 uppercase!">Dernieres inscriptions  </flux:heading>
 <flux:table>
            <flux:table.columns>
                <flux:table.column>Matricule</flux:table.column>
                <flux:table.column>Nom & Prenom</flux:table.column>
                <flux:table.column>Sexe</flux:table.column>
                {{-- <flux:table.column>Date de naissance</flux:table.column> --}}
                <flux:table.column>Formation</flux:table.column>
                <flux:table.column>Session</flux:table.column>
                <flux:table.column>Statut</flux:table.column>

                <flux:table.column>Action</flux:table.column>
            </flux:table.columns>
            <flux:table.rows>
                @forelse ($inscriptions as $inscription)
                    <flux:table.row>
                        <flux:table.cell>{{ $inscription->aprenant->matricule ?? '' }}</flux:table.cell>
                        <flux:table.cell> {{ $inscription->aprenant->user->name ?? '' }}
                            {{ $inscription->aprenant->prenom }}</flux:table.cell>
                        <flux:table.cell> {{ $inscription->aprenant->sexe == 'M' ? 'Masculin' : 'Feminin' ?? '' }}
                        </flux:table.cell>
                        {{-- <flux:table.cell>{{ $inscription->aprenant->dateNaissance ?? '' }}</flux:table.cell> --}}
                        <flux:table.cell>{{ $inscription->sessionn->formation->nom }}</flux:table.cell>
                        <flux:table.cell> {{ $inscription->sessionn->dateDebut->format('Y/m/d') ?? '' }} Au
                            {{ $inscription->sessionn->dateFin->format('Y/m/d') ?? '' }}</flux:table.cell>
                        <flux:table.cell> <span @class([
                            'font-extrabold rounded-md px-2 py-1',

                            'bg-yellow-100 text-yellow-700' => $inscription->statut === 'En attente',

                            'bg-green-100 text-green-700' => $inscription->statut === 'Validée',

                            'bg-red-100 text-red-700' => $inscription->statut === 'Refusée',

                            'bg-blue-100 text-blue-700' => $inscription->statut === 'En formation',

                            'bg-purple-100 text-purple-700' => $inscription->statut === 'Terminée',

                            'bg-gray-200 text-gray-700' => $inscription->statut === 'Abandonnée',
                        ])>
                                {{ $inscription->statut }}
                            </span></span>
                        </flux:table.cell>
                        <flux:table.cell>
                            <flux:button href="{{ route('formateurs', $inscription->id) }}" icon="eye"
                                variant="primary"></flux:button>

                            <flux:button href="{{ route('ajouterInscription', $inscription->id) }}" icon="pencil">

                            </flux:button>

                
                        </flux:table.cell>



                    </flux:table.row>
                @empty
                @endforelse
            </flux:table.rows>
        </flux:table>
        {{ $inscriptions->links() }}

    </div>
</div>
